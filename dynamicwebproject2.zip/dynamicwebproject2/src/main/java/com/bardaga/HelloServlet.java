package com.bardaga;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@WebServlet("/HelloServlet")
public class HelloServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Logger instance
    private static final Logger logger = LogManager.getLogger(HelloServlet.class);

    // Database connection parameters
    private static final String DB_URL = "jdbc:postgresql://localhost:5432/student_management_db";
    private static final String DB_USER = "postgres";
    private static final String DB_PASSWORD = "Diar55!!";

    public HelloServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        logger.info("Received GET request at /HelloServlet");
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h2>Welcome to the Hello Servlet!</h2>");
        out.println("<p>Please use the form to submit your details.</p>");
        out.println("</body></html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");

        logger.info("Received POST request with data: ID={}, FirstName={}, LastName={}", id, firstName, lastName);

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            logger.debug("Database connection established");

            String sql = "INSERT INTO users (id, first_name, last_name) VALUES (?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, id);
                statement.setString(2, firstName);
                statement.setString(3, lastName);
                statement.executeUpdate();
                logger.info("Data inserted successfully into database");
            }

            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<html><body>");
            out.println("<h2>Data submitted successfully!</h2>");
            out.println("<p>ID: " + id + "</p>");
            out.println("<p>First Name: " + firstName + "</p>");
            out.println("<p>Last Name: " + lastName + "</p>");
            out.println("</body></html>");
        } catch (SQLException e) {
            logger.error("Database connection error", e);
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database connection error");
        }
    }
}

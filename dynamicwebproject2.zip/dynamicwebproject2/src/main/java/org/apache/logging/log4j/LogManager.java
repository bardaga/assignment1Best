package org.apache.logging.log4j;

import com.bardaga.HelloServlet;

public class LogManager {

	public static Logger getLogger(Class<HelloServlet> class1) {
		// TODO Auto-generated method stub
		return null;
	}

}
